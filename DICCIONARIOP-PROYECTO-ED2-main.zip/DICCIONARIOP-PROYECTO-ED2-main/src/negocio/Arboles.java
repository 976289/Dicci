
package negocio;

import arboles.Excepciones.ExcepcionOrdenInvalido;
import java.util.Scanner;

public class Arboles {

    /**
     * @param args the command line arguments
     * @throws arboles.Excepciones.ExcepcionOrdenInvalido
     */
    public static void main(String[] args) throws ExcepcionOrdenInvalido {
    
    }

}
